# QiuMoTool

#### 介绍
QiuMoTool,免费开源小工具，仅供学习，请勿做违法违规的事情，一切后果作者概不负责。


#### 安装教程

直切丢到服务器即可

#### 使用说明

1.  php版本自测，php需安装exif依赖

![输入图片说明](https://images.gitee.com/uploads/images/2021/0825/100944_87dcd2b4_7382579.png "SA%5PQT0M]2KXOZ)1PLZ3`N.png")

2.  api文件夹中的class文件需要配置一下key（仅获取头像接口需要用到，不用可不配置）

```
<?php
/**
 * 聚合api
 */
class api {
    public $key="这里是key";
```

